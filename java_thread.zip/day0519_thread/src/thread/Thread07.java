package thread;

public class Thread07 implements Runnable{
	
	private String name;
	
	public Thread07(String name) {
		this.name=name;
	}
	@Override
	public void run() {
		
		for(int i=1; i<=5 ; i++) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
			
			System.out.println(name + " : " + i);
		}
		
	}

}
