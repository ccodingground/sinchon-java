package thread;

public class Thread03 extends Thread{

	@Override
	public void run() {
		for(int i=1; i<10000; i++) {
			System.out.print("TH_333_"+i+"  ");
			if(i%5==0)
				System.out.println();
		}
	}
	

}
