package thread;

public class Thread02 {
	
	public static void main(String[] args) {
		//System.out.println(Thread.MAX_PRIORITY);//10
		//System.out.println(Thread.MIN_PRIORITY);//1
		//System.out.println(Thread.NORM_PRIORITY);//5
		
		//따로설정하지 않으면 NORM_PRIORITY
		
		Thread03 th3=new Thread03();
		th3.setPriority(Thread.MAX_PRIORITY);//1~10
		//Runnable run4=new Thread04();
		//th4.start();
		Thread th4=new Thread(new Thread04());
		th4.setPriority(7);//1~10
		//설정은 꼭 start() 실행 전에 처리 하여야한다...
		th3.start();
		th4.start();
		
		
	}

}
