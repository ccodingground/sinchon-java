package thread;

public class Thread04 implements Runnable{

	@Override
	public void run() {
		for(int i=1; i<10000; i++) {
			System.out.print("TH_444_"+i+"  ");
			if(i%5==0)
				System.out.println();
		}
	}

}
