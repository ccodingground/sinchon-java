package thread;

public class Thread05 extends Thread{
	
	@Override
	public void run() {
		System.out.println("Thread05");
	}
	
	public Thread05(ThreadGroup tg, String name) {
		super(tg, name);
	}

}
