package thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPoolTest {

	public static void main(String[] args) {
		
		ExecutorService exec=Executors.newFixedThreadPool(2);
		
		//Runnable runnable1=new Thread07("첫번째");
		//Runnable runnable2=new Thread07("두번째");
		//Runnable runnable3=new Thread07("세번째");
		
		Runnable[] runnable=new Runnable[] {
				new Thread07("첫번째"), new Thread07("두번째"),
				new Thread07("세번째"), new Thread07("네번째")
		};
		
		for(Runnable r : runnable) {
			exec.execute(r);
		}
		//for(Runnable r :runnable) {
		//	Thread th=new Thread(r);
		//	th.start();
		//}
		
		
		
	}

}
