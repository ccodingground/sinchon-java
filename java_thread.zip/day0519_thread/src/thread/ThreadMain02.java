package thread;

public class ThreadMain02 {

	public static void main(String[] args) {
		System.out.println("메인스레드 시작!");
		Runnable dog=new Dog("비글");
		Runnable cat=new Cat("도둑고양이");
		
		//dog.run();-->start()
		//cat.run();-->start()
		
		Thread dogThread=new Thread(dog);
		Thread catThread=new Thread(cat);
		dogThread.setDaemon(true);
		catThread.setDaemon(true);
		System.out.println("비글 과 도둑고양이의 경주 시작!!!");
		dogThread.start();//run()실행
		catThread.start();//run()실행
		System.out.println("메인스레드 종료!");
		
		
	}

}
