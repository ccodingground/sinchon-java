package thread;

import java.util.Random;

public class Cat extends Animal implements Runnable{

	public Cat(String name) {
		super(name);
	}

	@Override
	public void run() {
		
		for(int i=0; i<=100; ) {
			Random random=new Random(System.nanoTime());
			try {
				Thread.sleep(random.nextInt(100)+1);
			} catch (InterruptedException e) {
			}
			
			
			i += random.nextInt(10)+1;
			if(i>100) {//i 99 + 5=104
				break;
			}
			System.out.println(getName()+"위치 : "+i+"m 달리는중~");
		}//for END
		System.out.println(getName()+"결승선 도착 !!!!!! 야옹~야옹~~");
		
	}

}
