package thread;

public class Thread06 extends Thread{
	
	@Override
	public void run() {
		System.out.println("Thread06");
	}
	
	public Thread06(ThreadGroup tg, String name) {
		super(tg, name);
	}

}
