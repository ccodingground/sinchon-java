package thread;

public class ThreadSync implements Runnable{

	@Override
	public void run() {
		System.out.println("스레드 시작");
		//sync01();
		sync02();
		System.out.println("스레드 종료");		
	}
	//synchronized 메서드 통채로..
	private synchronized static void sync01() {
		System.out.println("sync01 메서드 실행!");
		String tName=Thread.currentThread().getName();
		
		
		for(int i=1; i<=10; i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}
			System.out.println(tName+" : "+i);
		}
		
		System.out.println("sync01 메서드 종료!");
		
	}
	
	private  static void sync02() {
		System.out.println("sync01 메서드 실행!");
		String tName=Thread.currentThread().getName();
		//////////////////////////////////////
		for(int i=1; i<=3; i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}
			System.out.println(tName+"pre : "+i);
		}
		//메서드 전체에 synchronized처리하기에는 시간소가 너무 길떄
		//부분영역으로 처리 가능하다...
		//중요한 로직
		synchronized (ThreadSync.class) {
			System.out.println("중요 구간처리 시작");
			for(int i=1; i<=3; i++) {
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
				}
				System.out.println(tName+"IMPORTANT : "+i);
			}
			System.out.println("중요 구간처리 종료");
		}
		////////////////////////////////////////
		for(int i=1; i<=3; i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
			}
			System.out.println(tName+"next : "+i);
		}
		
		System.out.println("sync01 메서드 종료!");
		
	}

	

}
