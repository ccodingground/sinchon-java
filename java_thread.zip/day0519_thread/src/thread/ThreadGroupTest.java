package thread;

public class ThreadGroupTest {

	public static void main(String[] args) {
		
		ThreadGroup mainGroup=Thread.currentThread().getThreadGroup();
		
		ThreadGroup aGroup=new ThreadGroup(mainGroup,"aGroup");
		ThreadGroup bGroup=new ThreadGroup(mainGroup,"bGroup");
		aGroup.setDaemon(true);
		bGroup.setMaxPriority(1);
		
		Thread05 th01=new Thread05(aGroup, "첫번째");
		Thread05 th02=new Thread05(aGroup, "두번째");
		
		Thread06 th03=new Thread06(bGroup, "세번째");
		Thread06 th04=new Thread06(bGroup, "네번째");
		th01.start();
		th02.start();
		th03.start();
		th04.start();
		//System.out.println("------------------");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mainGroup.list();


	}

}
