package thread;

public class ThreadMain01 {

	public static void main(String[] args) {
		
		System.out.println("main 스레드 시작");
		
		Thread01 thread=new Thread01("otherThread");
		//thread.run(); //단지 메서드 실행과 동일 run()
		//run() 실행하는 방법을 ---> start()를 통해서 한다.
		thread.start();// run()실행시켜준다.
		
		for(int i=0; i<10; i++) {
			
			System.out.println("main 스레드 : "+ i);
			
			try {
				Thread.sleep(500);//1000 - 1초
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
		
		System.out.println("main 스레드 종료");

	}

}
