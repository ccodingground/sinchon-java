package thread;

public class Thread01 extends Thread{

	@Override
	public void run() {
		System.out.println(this.getName()+"시작!");
		for(int i=0; i<10; i++) {
			
			System.out.println(this.getName()+" : "+ i);
			
			try {
				Thread.sleep(500);//1000 - 1초
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
		
		System.out.println(this.getName()+"종료!");
	}
	
	public Thread01(String name) {
		super(name);
	}
	

}
