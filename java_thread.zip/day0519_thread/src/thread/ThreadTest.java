package thread;

public class ThreadTest {

	public static void main(String[] args) {
		
		int count=Thread.activeCount();
		System.out.println("실행되는 스레드 수: "+count);
		Thread curr=Thread.currentThread();
		System.out.println("스레드 객체 정보 :"+ curr);
		System.out.println("스레드 이름 : "+ curr.getName());
		System.out.println("priority : "+ curr.getPriority());
		System.out.println("isAlive : "+ curr.isAlive());
		System.out.println("isDeamon : "+ curr.isDaemon());

	}

}
