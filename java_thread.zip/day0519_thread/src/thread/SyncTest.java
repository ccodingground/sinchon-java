package thread;

import java.util.Arrays;

public class SyncTest {

	public static void main(String[] args) {
		
		
		Runnable run=new ThreadSync();
		Runnable run2=new ThreadSync();
		
		Thread th01=new Thread(run,"첫번째");
		Thread th02=new Thread(run2,"두번째");
		
		th01.start();
		th02.start();

	}

}
