package accessMofifiers2;

public class CCC extends BBB{
	private int x;
	private int y;
	
	void disp() {
		System.out.println( x );
		System.out.println( y );
		/////////////////////////
		System.out.println( a );
		System.out.println( b );
		//System.out.println( c );//private
		System.out.println( d );
	}

}
