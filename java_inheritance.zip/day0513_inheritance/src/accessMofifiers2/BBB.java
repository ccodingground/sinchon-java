package accessMofifiers2;

public class BBB {
	
	public int a;
	int b;
	private int c;
	protected int d;

}
