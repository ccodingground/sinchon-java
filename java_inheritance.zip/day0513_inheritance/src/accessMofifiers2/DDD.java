package accessMofifiers2;

import accessModifiers.AAA;

public class DDD extends AAA{
	
	private int x;
	private int y;
	
	
	void disp() {
		System.out.println( x );
		System.out.println( y );
		///////////////////////
		System.out.println( a );
		//System.out.println( b );//package //서로다른 package
		//System.out.println( c );//prvate
		System.out.println( d );//상속관계이기에 접근 허용
	}
	

}
