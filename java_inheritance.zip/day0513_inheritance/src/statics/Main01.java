package statics;

public class Main01 {

	public static void main(String[] args) {
		
		//Test01 obj=new Test01();
		//System.out.println(obj.a);
		//System.out.println(obj.b);
		System.out.println(Test01.PI);
		System.out.println(Test01.plus(10, 20));
		System.out.println(Test01.minus(5, 3));
		
	}

}
