package statics;

public class Test02 {
	
	int a=100;
	void method1() {}
	
	static int b=10;
	static int c=20;
	static int d;
	static void method2() {}
	//static 필드에 대한 초기화 작업
	static {
		d=b+c;
	}

}
