package statics;

public class Test01 {
	//멤버 필드
	static final double PI=3.14;//정적(고정)
	//공유의 목적으로 사용하기 위해서 만든 필드..
	static int plus(int  a, int b) {
		//PI=3.25;
		return a+b;
	}
	
	static int minus(int  a, int b) {
		return a-b;
	}

}
