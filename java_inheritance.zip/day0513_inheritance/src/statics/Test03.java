package statics;

public class Test03 {
	
	static int a;
	private Test03() {
		// TODO Auto-generated constructor stub
	}

}
