package statics;

import java.util.Scanner;

public class InputProcess {
	
	private static Scanner in;
	
	public static Scanner getScanner() {
		new InputProcess();
		return in;
	}
	
	public InputProcess() {
		in=new Scanner(System.in);
	}
}
