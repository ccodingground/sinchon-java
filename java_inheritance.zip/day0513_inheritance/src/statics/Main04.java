package statics;

public class Main04 {
	
	public static void main(String[] args) {
		System.out.println(Math.PI);
		//Test03 obj=new Test03();
		//System.out.println(obj.a);
		System.out.println(Test03.a);
	}

}
