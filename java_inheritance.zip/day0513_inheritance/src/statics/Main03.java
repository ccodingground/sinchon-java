package statics;

public class Main03 {

	public static void main(String[] args) {

		int a=InputProcess.getScanner().nextInt();
		System.out.println(a);

	}

}
