package statics;

public class Test04 {
	
	//상수...
	//10=9;
	static final double MATH_PI=3.14;
	Test04(){
		//pi=3.141592;
	}

}
