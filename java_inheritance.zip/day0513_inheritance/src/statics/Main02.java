package statics;

public class Main02 {
	
	public static void disp() {
		
	}
	public void disp2() {
		disp();
	}
	

	public static void main(String[] args) {
		
		disp();
	}

}
