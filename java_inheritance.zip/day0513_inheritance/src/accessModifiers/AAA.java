package accessModifiers;

public class AAA {
	
	public int a;
	int b;
	private int c;
	protected int d;

}
