package accessModifiers;

import accessMofifiers2.BBB;

public class Test01 {
	
	//public int a;//어디서든 접근가능
	//int b;//package 명시하면 에러.. //동일 package내서서 접근가능
	//private int c;//제일강력,,,동일 class 내에서만 접근가능
	//protected int d;//동일 package + 상속의 경우 접근가능
	
	//public > protected > package > private
	
	public static void main(String[] args) {
		AAA aaa=new AAA();
		System.out.println(aaa.a);
		System.out.println(aaa.b);
		//System.out.println(aaa.c);//private
		System.out.println(aaa.d);
		
		///////////////////////////////
		//Timestamp time;
		
		BBB b=new BBB();
		System.out.println(b.a);
		//System.out.println(b.b);//package타입은 다른폴더(package)에서 접근불가
		//System.out.println(b.c);//private
		//System.out.println(b.d);//protected 
		
	}

}
