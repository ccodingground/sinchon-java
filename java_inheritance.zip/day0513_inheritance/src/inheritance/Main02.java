package inheritance;

public class Main02 {

	public static void main(String[] args) {
		
		
		Super02 obj1=new Sub02();//Sub02(), Super02()
		//Sub02 obj2=new Sub02();
		obj1.display();
		

	}

}
