package inheritance;

public class MainTest01 {

	public static void main(String[] args) {
		
		Super01 su=new Super01();
		System.out.println(su.a);
		System.out.println(su.b);
		
		Sub01 sub=new Sub01();
		System.out.println(sub.x);
		System.out.println(sub.y);
		System.out.println(sub.a);
		System.out.println(sub.b);
		sub.disp();
		sub.show();
		sub.dispA();
		System.out.println("------------------------");
		////////////////////////////////
		Sub01 su1=new Sub01();//super();==>
		Super01 su2=new Sub01();//super();==>
		//Object su3=new Sub01();//super();==>
		System.out.println(su2.a);
		System.out.println(su2.b);
		//System.out.println(su2.x);
		su2.disp();//????????
		//override
		
		
		
	}

}
