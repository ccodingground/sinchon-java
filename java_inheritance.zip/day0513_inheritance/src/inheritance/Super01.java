package inheritance;

public class Super01 {
	
	protected int a=100;
	protected int b;
	
	void disp() {
		System.out.println("Super01클래스의 disp()입니다.");
	}

	

}
