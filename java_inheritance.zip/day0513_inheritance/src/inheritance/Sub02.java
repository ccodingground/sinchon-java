package inheritance;

public class Sub02 extends Super02{
	
	@Override
	public void display() {
		System.out.println("Sub클래스의 메서드입니다.");
		//super.display();
	}
	public Sub02() {
		//super();
	}

}
