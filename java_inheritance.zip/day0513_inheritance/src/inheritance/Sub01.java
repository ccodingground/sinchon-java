package inheritance;

public class Sub01 extends Super01{
	int x;
	int y;
	int a=10;
	
	void dispA() {
		System.out.println("sub_a : " + a);
		System.out.println("super_a : " + super.a);
	}
	
	void show() {
		System.out.println("Sub 클래스의 메서드입니다.");
		super.disp();
	}
	
	
	public Sub01(int x, int y, int a) {
		//super();
		this.x = x;
		this.y = y;
		this.a = a;
	}

	public Sub01() {
		//super();
		// TODO Auto-generated constructor stub
	}

	@Override//메서드 재정의
	void disp() {
		System.out.println("Sub에서 다시 고쳤어요!");
	}
	
	
	
	
	
	
	
	
}
