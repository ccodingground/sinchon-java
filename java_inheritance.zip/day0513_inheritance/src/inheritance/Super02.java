package inheritance;

public class Super02 {
	//int a;
	void display() {
		System.out.println("Super의 메서드");
	}
	//미완성 메서드
	//추상 메서드

}
