package getterAndSetter;

public class Main01 {

	public static void main(String[] args) {
		
		Test01 t=new Test01();
		
		t.setName(new String("조재청"));
		t.setId("aaaa");
		t.setPw("1234");
		t.setAge(20);
		t.setCheck(true);
		
		
		System.out.println( t.getName() );
		System.out.println( t.getId() );
		System.out.println( t.getPw() );
		System.out.println( t.getAge() );
		System.out.println( t.isCheck() );

	}

}
