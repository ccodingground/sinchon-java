package ex;

public class Exam {
	
	String name;
	int kor;
	int eng;
	int mat;
	int tot;
	double avg;
	//메서드
	void calcuTotAndAvg() {
		tot = kor+eng+mat;
		avg = tot/3.0;
	}
	
	int calcuTot() {
		return kor+eng+mat;
	}
	//생성자
	public Exam(String name, int kor, int eng, int mat) {
		this.name=name;
		this.kor=kor;
		this.eng=eng;
		this.mat=mat;
		//tot = this.kor+this.eng+this.mat;
		//tot = calcuTot();
		//avg = tot/3.0;
		calcuTotAndAvg();
	}

	@Override
	public String toString() {
		return "Exam [name=" + name + ", kor=" + kor + ", eng=" + eng + ", mat=" + mat + ", tot=" + tot + ", avg=" + avg
				+ "]";
	}
	
	

}
