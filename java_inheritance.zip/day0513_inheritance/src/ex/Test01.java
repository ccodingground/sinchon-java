package ex;

public class Test01 {

	public static void main(String[] args) {
		
		String[] name={"차승원","유해진","손호준"};
		int[] kor=new int[] {100,90,88};
		int[] eng= {95,95,100};
		int[] mat= {88,88,92};
		
		int[] tot=new int[3];
		double[] avg=new double[3];
		int[] rank=new int[3];
		
		//총점과 평균 입력
		for(int i=0; i<3; i++) {
			tot[i]= kor[i]+eng[i]+mat[i];
			avg[i]= tot[i]/3.0;
		}
		//순위 처리
		for(int k=0; k<3; k++) {
			rank[k]=1;
			
			for(int i=0; i<3; i++) {
				if(tot[k]<tot[i]) {
					rank[k]++;
				}
			}
		}
		
		//출력
		
		for(int i=0; i<3; i++) {
			System.out.printf("%s : %3d , %3d , %3d , %3d, %.2f , %d\n",
					name[i], kor[i], eng[i], mat[i], tot[i], avg[i], rank[i]);
		}
		

	}

}
