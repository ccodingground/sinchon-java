package ex;

public class ExamMain {

	public static void main(String[] args) {
		
		Exam[] ex1=new Exam[3];
		ex1[0]=new Exam("차승원", 90, 90, 90);
		ex1[1]=new Exam("유해진", 80, 80, 80);
		ex1[2]=new Exam("손호준", 70, 70, 70);
		
		for(Exam ex :ex1) {
			System.out.println(ex);
		}
		
		//ex1.name="차승원";
		//ex1.kor=100;
		//ex1.eng=80;
		//ex1.mat=90;
		//ex1.tot= ex1.kor+ex1.eng+ex1.mat;
		//ex1.avg=ex1.tot/3.0;

		

	}

}
