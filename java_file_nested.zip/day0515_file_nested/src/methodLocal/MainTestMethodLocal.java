package methodLocal;

public class MainTestMethodLocal {

	public static void main(String[] args) {
		Outer out=new Outer();
		out.outerMethod();

	}

}
