package methodLocal;


public class Outer {
	
	int num=10;
	
	void outerMethod() {
		int x=10;
		class Inner{
			int a=100;
			void disp() {
				System.out.println(x);
				System.out.println(a);
				class AAA{}
			}
		}
		class IN{}
		//Outer$1Inner.class
		
		Inner inner=new Inner();
		inner.disp();
	}//outerMethod END
	void disp() {
		outerMethod();
		//Inner in=new Inner();
		//클래스가 정의되어있는 해당 메서드 내부에서만 접근가능
	}

}
