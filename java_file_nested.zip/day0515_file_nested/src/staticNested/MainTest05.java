package staticNested;

public class MainTest05 {

	public static void main(String[] args) {
		Outer05 ot=new Outer05();
		
		Outer05.Inner06 inner06=ot.new Inner06();
		Outer05.Inner06 inner06_1=new Outer05().new Inner06();
		
		//static inner class 객체 생성방법
		Outer05.Inner05 inner05=new Outer05.Inner05();
		
		//Outer05$Inner05.class
	}

}
