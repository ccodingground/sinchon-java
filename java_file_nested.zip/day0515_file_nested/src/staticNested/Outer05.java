package staticNested;

public class Outer05 {
	int a;
	static int b;
	static class Inner05{
		void disp() {
			//System.out.println(a);//접근불가
			System.out.println(b);
			//static멤버만 접근 가능합니다.
		}
	}
	class Inner06{
		void disp() {
			System.out.println(a);
			System.out.println(b);
		}
	}
	private static class Inner07{
		
	}
	
	void process() {
		//Inner07 inner07=new Inner07();
		Outer05.Inner07 inner07_1=new Outer05.Inner07();
	}
	
	
}
