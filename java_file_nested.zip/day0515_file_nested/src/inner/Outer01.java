package inner;

public class Outer01 {
	private int x=100;
	
	// 접근제한자 사용 4개 다 가능하다..
	private class Inner01{
		//
		//class Inner01_01{}
		int y=200;
		//int x=300;//
		public void display() {
			System.out.println(x);
			System.out.println(y);
		}
		
	}
	
	void disp() {
		//내부에서는 일반 객체 생성 방법으로 객체 생성가능
		Inner01 a=new Inner01();
		a.display();
	}

}
