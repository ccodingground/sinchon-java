package inner;

public class MainTest01 {

	public static void main(String[] args) {
		
		Outer01 ot=new Outer01();
		
		//Outer01.Inner01 inner=new Outer01.Inner01();
		//non-static _ innerClass 객체 생성방법
		//Outer01.Inner01 inner=ot.new Inner01();
		ot.disp();

	}

}
