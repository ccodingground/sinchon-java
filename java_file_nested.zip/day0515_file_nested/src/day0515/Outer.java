package day0515;

public class Outer {
	//1. 멤버필드
	//2. 멤버메서드
	//3. 생성자
	//4. 내부 클래스
	public class Inner{
		
	}
	//Outer$Inner.class

}
