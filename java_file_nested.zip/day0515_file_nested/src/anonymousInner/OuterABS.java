package anonymousInner;

public abstract class OuterABS {
	
	abstract void disp1();

}
