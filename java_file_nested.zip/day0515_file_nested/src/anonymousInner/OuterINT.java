package anonymousInner;

public interface OuterINT {
	
	void interMethod();

}
