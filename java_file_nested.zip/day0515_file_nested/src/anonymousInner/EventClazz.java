package anonymousInner;

public class EventClazz {
	
	public void event(OuterINT inter) {
		inter.interMethod();
	}

}
