package anonymousInner;

public class MainTest03 {

	public static void main(String[] args) {
		
		//OuterABS abs=new OuterABS();
		
		OuterABS abs=new OuterABS() {
			
			@Override
			void disp1() {
				System.out.println("AnonymousInner Test");
				
			}
		};
		//MainTest03$1.class
		abs.disp1();
		
		//OuterINT inter=new OuterINT();
		OuterINT inter=new OuterINT() {
			
			@Override
			public void interMethod() {
				System.out.println("AnonymousInner Test2");
				
			}
		};
		//MainTest03$2.class
		inter.interMethod();
		
		
		EventClazz e=new EventClazz();
		e.event(new OuterINT() {
			
			@Override
			public void interMethod() {
				System.out.println("이벤트 메서드");
				
			}
		});
		
		//java8버전부터 사용
		e.event(()->{
			System.out.println("람다식 표현 메서드");
		});
		
		

	}

}
