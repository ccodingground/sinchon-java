package file;

import java.io.FileWriter;
import java.io.IOException;

public class WriterTest01 {

	public static void main(String[] args) throws Exception {
		
		FileWriter fw=null;
		fw=new FileWriter("test04.txt");
		
		fw.write('가');
		fw.write('나');
		fw.write('다');
		
		if(fw!=null)fw.close();
		
		

	}

}
