package file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test02 {

	public static void main(String[] args) {
		String f=File.separator;
		File file=new File("./src/file/test01.txt");
		FileOutputStream fos=null;
		try {
			fos=new FileOutputStream(file);
			fos.write('A');
			fos.write('B');
			fos.write('C');
			
			System.out.println("저장완료!");
		} catch (FileNotFoundException e) {
			System.out.println("파일이 존재하지 않습니다.");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			
			try {if(fos!=null)fos.close();} catch (IOException e) {}
			
		}
	}

}
