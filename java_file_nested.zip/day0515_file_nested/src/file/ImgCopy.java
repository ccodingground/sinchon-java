package file;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class ImgCopy {

	public static void main(String[] args) throws Exception {
		
		FileInputStream fis=null;
		FileOutputStream fos=null;
		//스트림 연결
		fis=new FileInputStream("img_1.jpg");//파일이 존재하지않으면 예외발생
		fos=new FileOutputStream("img_1_copy.jpg");
		int data;
		while((data=fis.read()) != -1) {
			//읽어들인 데이터를 복사진행합시다.
			fos.write(data);
		}
		System.out.println("복사완료!");
		//스트림 종료
		if(fos!=null)fos.close();
		if(fis!=null)fis.close();

	}

}
