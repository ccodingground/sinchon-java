package file;

import java.io.File;

public class Test01 {

	public static void main(String[] args) {


		
		File dir=new File("D:\\java\\workspace\\day0515\\src\\file");
		if(dir.isDirectory()) {
			System.out.println("디렉토리입니다.");
		}
		File file=new File(dir,"test01.txt");
		if(file.isFile()) {
			System.out.println("파일입니다.");
		}
		
		
		
		//절대경로
		//상대경로

	}

}
