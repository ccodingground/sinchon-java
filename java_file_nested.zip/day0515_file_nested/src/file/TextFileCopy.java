package file;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;

public class TextFileCopy {

	public static void main(String[] args) throws Exception {
		
		FileReader fr=null;
		FileWriter fw=null;
		
		fr=new FileReader("./src/file/input.txt");
		fw=new FileWriter("input_copy.txt");
		/*
		int data;
		while(true) {
			data=fr.read();
			if(data == -1) {//탈출조건
				break;
			}
			fw.write(data);
		}
		*/
		int data;
		while((data=fr.read()) != -1) {
			
			fw.write(data);
		}
		
		
		if(fr!=null)fr.close();
		if(fw!=null)fw.close();

	}

}
