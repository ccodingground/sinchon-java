package file;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ReaderTest {

	public static void main(String[] args) throws Exception {
		
		FileReader fr=null;
		fr=new FileReader("D:/java/workspace/day0515/test04.txt");
		//파일이 존재하지 않으면 예외발생!!!!!!!!
		int data;
		while((data=fr.read()) !=-1) {
			System.out.printf("%c", data);
		}
		
		if(fr!=null)fr.close();

	}

}
