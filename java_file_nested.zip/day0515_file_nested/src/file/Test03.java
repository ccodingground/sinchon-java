package file;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Test03 {

	public static void main(String[] args) throws Exception {
		
		FileOutputStream fos=null;
		fos=new FileOutputStream("test03.txt");
		
		fos.write('a');
		fos.write('b');
		fos.write('c');
		
		
		if(fos!=null)fos.close();
		

	}

}
