package file;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Test04 {

	public static void main(String[] args) throws Exception {
		
		FileInputStream fis=null;
		
		fis=new FileInputStream("./src/file/test01.txt");
		/*
		while(true) {
			int data=fis.read();
			if(data==-1)
				break;//반복문 탈출
			System.out.printf("%c",data);
		}
		*/
		int data;
		while((data=fis.read()) != -1) {
			System.out.printf("%c",data);
		}
		
		
		if(fis!=null)fis.close();

	}

}
