package format;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Formatter;

import com.sun.glass.ui.Pixels.Format;

public class FotmatTest {

	public static void main(String[] args) {
		
		Formatter f=new Formatter();
		f.format("%d + %d = %d\n", 2,2,2+3);
		System.out.println(f);
		
		
		System.out.printf("%d + %d = %d\n", 2,2,2+3);
		//%B %b boolean
		//%c char
		//%d 10진수 정수형 데이터
		//%o 8진수형 데이터
		//%x 16진수형
		//%f 실수형데이터
		//%s 문자열
		//%t 날짜형
		//%n 개행
		//%% '%'문자 출력
		
		LocalDateTime date=LocalDateTime.now();
		f.format("%tY년 %tm월 %te일%n", date, date, date);
		System.out.println(f);
		
		f.format("%tk시 %tM분 %tS초%n", date, date, date);
		System.out.println(f);
		
		SimpleDateFormat datef=new SimpleDateFormat(""
				+ "yyyy년 MM월 dd일 E요일 a HH시 mm분 ss초 SSS");
		
		Calendar ca=Calendar.getInstance();
		
		System.out.println(datef.format(ca.getTime()));
		
		

	}

}
