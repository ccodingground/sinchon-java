package strings;

public class StringTest01 {

	public static void main(String[] args) {

		String str1="안녕하세요";
		String str2="안녕하세요";
		String str3=new String("안녕하세요");
		System.out.println(str3);
		
		if(str1==str3) {
			System.out.println("같은 문자열입니다.");
		}else {
			System.out.println("다릅니다.");
		}
		//문자열비교시 상황에 따라 같을수도있고 다를수도 있다...
		
		System.out.println("----------------");
		//문자열비교시
		
		if(str1.equals(str3)){
			System.out.println("같은 문자열입니다.");
		}else {
			System.out.println("다릅니다.");
		}

	}

}
