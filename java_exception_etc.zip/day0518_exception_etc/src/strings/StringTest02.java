package strings;

public class StringTest02 {

	public static void main(String[] args) {


		//String str="abcde";
		//                     0123456789012
		String str=new String("hello java java!");
		System.out.println("문자열길이 : "+ str.length());
		
		System.out.println(str.indexOf("java"));//문자열시작 위치의 인덱스반환
		System.out.println(str.indexOf("javv"));//-1 
		System.out.println(str.lastIndexOf("java"));//동일한문자열중 제일 마지막 문자열의 인덱스
		
		String str2=str.substring(6);
		System.out.println(str2);
		
		String str3=str.substring(6, 12);
		System.out.println(str3);
		System.out.println("첫번째 문자 : "+ str.charAt(0));
		
		System.out.println(str.contains("ja"));
		System.out.println(str.contains("aj"));
		
		System.out.println(str.isEmpty());
		str="";
		System.out.println(str.isEmpty());
		
		String path="D:/java/workspace/day0518/test.txt";
		//D:
		//java
		//workspace
		//day0518
		//test.txt
		String[] strs=path.split("/");
		System.out.println(strs[0]);
		System.out.println(strs[1]);
		System.out.println(strs[2]);
		System.out.println(strs[3]);
		System.out.println(strs[4]);
		
		System.out.println("전부 대문자로바꿉시다");
		System.out.println(path.toUpperCase());
		System.out.println("소문자로 변경");
		System.out.println(path.toLowerCase());
		
		//
		str="    삼 시 세 끼      ";
		System.out.println(str);
		System.out.println(str.trim());//문자열 앞뒤의 공백제거
		
		
		str="자바 스프링 jsp html";
		
		String[] strs2=str.split(" ");
		for(String s:strs2) {
			System.out.println(s);
		}
		
		String url="https://www.oracle.com/java/technologies/javase-downloads.html";
		//String url="https://news.v.daum.net/v/20200518141601166";
		//경로에서 제일 마지막 의 문자열만...
		String[] urls=url.split("/");
		//System.out.println( urls[0] );
		//System.out.println( urls[1] );
		//System.out.println( urls[2] );
		//System.out.println( urls[4] );
		System.out.println( urls[urls.length-1] );
		//배열의 마지막 인덱스 == 배열이름.length - 1
		

	}

}
