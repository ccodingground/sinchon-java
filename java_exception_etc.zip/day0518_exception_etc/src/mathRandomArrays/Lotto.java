package mathRandomArrays;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Lotto {
	
	static void createNums() {
		Random ran=new Random(System.nanoTime());
		int lotto[]=new int[6];
		for(int i=0; i<6; i++) {
			int createNum=ran.nextInt(45)+1;
			
			//중복체크하세요..
			boolean check=false;
			for(int j=0; j<i ; j++) {
				if(createNum==lotto[j]) {//중복숫자 발생
					check=true;
				}
			}
			if(check) {
				i--;
				continue;
			}
			
			lotto[i]=createNum;
		}
		for(int i=0; i<6; i++)
			System.out.printf("%02d  ", lotto[i] );
		System.out.println();
		
		
	}

	public static void main(String[] args) {
		
		Scanner in=new Scanner(System.in);
		System.out.print("몇개? ");
		int n=in.nextInt();
		
		for(int i=0; i<n; i++) {
			createNums();
		}
		
		

	}

}
