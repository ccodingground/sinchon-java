package mathRandomArrays;

import java.util.Random;

public class Test02 {

	public static void main(String[] args) {
		int num=(int)(Math.random()*10)+1 ;
		// 0.0 <= Math.random()< 1.0
		//System.out.println(num);
		
		Random ran=new Random();
		//ran.setSeed(1000);
		ran.setSeed(System.nanoTime());
		//System.out.println(ran.nextInt(10));
		for(int i=0; i<6; i++)
			System.out.println(ran.nextInt(45)+1);
		
	}

}
