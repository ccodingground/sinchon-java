package mathRandomArrays;

public class Test01 {

	public static void main(String[] args) {
		
		System.out.println("e : " + Math.E);
		System.out.println("PI : "+ Math.PI);
		System.out.println("절대값 : "+ Math.abs(-20));
		System.out.println("버림 : " + Math.floor(12.999));
		System.out.println("반올림 : " + Math.round(12.999));
		System.out.println("올림 : " + Math.ceil(12.1));
		System.out.println("큰값 : " + Math.max(10, 20));
		System.out.println("작은값 : " + Math.min(10, 20));

	}

}
