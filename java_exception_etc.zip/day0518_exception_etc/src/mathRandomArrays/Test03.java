package mathRandomArrays;

import java.util.Arrays;

public class Test03 {

	public static void main(String[] args) {
		
		char[] data=new char[] {'j', 'a','v','a', '!'};
		char[] data2="java!".toCharArray();
		
		System.out.println(Arrays.equals(data, data2));
		
		//배열을 --->문자열로
		String str=Arrays.toString(data);
		System.out.println(str);
		
		
		//배열의 범위 복사 from부터~to이전까지
		char[] copy=Arrays.copyOfRange(data, 1, 3);
		System.out.println(Arrays.toString(copy));
		
		Arrays.sort(data);//data 배열의 정렬처리_오름차순정렬
		System.out.println(Arrays.toString(data));
		
		
		int position=Arrays.binarySearch(data, 'j');
		System.out.println(position);
		
		
		int rank[]=new int[5];
		Arrays.fill(rank, 1);
		System.out.println(Arrays.toString(rank));
		

	}

}
