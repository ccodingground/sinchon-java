package exceptions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Test03 {
	
	private void fileInput() throws IOException {
		FileInputStream fis;
		fis=new FileInputStream("input.txt");
		fis.read();
	}
	
	private void fileInput2() throws IOException {
		FileInputStream fis;
		fis=new FileInputStream("input.txt");
		fis.read();
	}
	
	
	public void inputRun() throws IOException {
		/*
		try {
			fileInput();
			fileInput2();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//*/
		
		fileInput();
		
	}
	public void run() throws IOException {
		inputRun();
	}

}
