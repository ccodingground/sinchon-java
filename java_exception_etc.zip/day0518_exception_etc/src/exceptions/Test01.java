package exceptions;

import java.util.Scanner;

public class Test01 {

	public static void main(String[] args) {
		
		int arr[]=new int[3];//0~2
		
		//System.out.println( arr[3] );
		//ArrayIndexOutOfBoundsException
		
		int n=100;
		int n1;
		Scanner in=new Scanner(System.in);
		System.out.println("정수를 넣어주세요(1~100)");
		n1=in.nextInt();
		
		try {
			System.out.println(n/n1);
			System.out.println("나눗셈 완료!");
			//ArithmeticException: / by zero
		}catch (Exception e) {
			System.out.println("너 0입력했자나..!");
			System.out.println("프로그램을 다시 시작하세요!");
			//e.printStackTrace();
		}finally {//선택적 사용가능
			System.out.println("무조건 실행되는 영역");
		}
		//예외처리 목적
		//1. 예외발생시 정상종료
		//2. 예외발생시 예외내용 보고 및 재실행
		//3. 예외발생시 무시하고 계속 실행
		//4. 예외발생시 대안이되는 결과를 대입
		
		//throw 예외 강제 발생
		//throws 예외전가
		//try{}catch{}finally{} 예외처리
		
		
		
		

	}

}









































