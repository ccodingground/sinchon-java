package exceptions;

public class MyExceptionEx {

	public static void main(String[] args) {
		
		
		int n=100;
		int m=0;
		int tot=0;
		try {
			tot=n/m;
		}catch (ArithmeticException e) {
			//e.printStackTrace();
			MyException mye= new MyException("나눗셈 예외", e);
			mye.printStackTrace();
			
			
		}finally {
			System.out.printf("%d / %d = %d\n", n, m, tot);
		}

	}

}
