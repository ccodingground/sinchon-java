package exceptions;

import java.util.Scanner;

public class Test04 {

	public static void main(String[] args) throws Exception {
		
		System.out.println("1을입력해주세요");
		int n;
		
		Scanner in=new Scanner(System.in);
		n=in.nextInt();
		
		assert n==1:"1이 아니네요!!";
		//System.out.println("n : "+ n);//확인하기위해 테스트출력
		
		if(n==1) {
			System.out.println("1 이 정상적으로 입력되었습니다.");
			System.exit(0);
		}
		
		//throw new Exception("1이 아니네요!!");//1이 아닌경우 체크하기위한...
		//-ea 어셜션 실행
		//-ea:클래스이름  해당클래스만 어셜선 실행
		//-ea:.. 현재 패키지 내 클래스들만 실행
		//-ea:패키지이름... 지정된 패키지내 클새스들만..
		//-da 어셜션 실행 않함
		
		//이클립스에서 VM argumenets에 -ea 입력후 실행
		
		//예외 처리 목적
		//프로그램 실행중 예상치 못한 상황을 가정하여 그에 대한 처리가 가능하게 하는 방법으로,
		// 프로그램의 정상종료, 예외내용 보고, 재실행등 을 목적으로 사용한다.
		
		//어설션이란
		//개발중에 true여야 하는 명제 를 검증해서 단정지어주는 기능으로 실행옵션을 통해 기능 제어.
		

	}

}
