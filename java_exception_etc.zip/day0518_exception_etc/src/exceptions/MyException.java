package exceptions;

import java.io.PrintStream;
import java.io.PrintWriter;

public class MyException extends Exception{
	
	private String message;
	private Throwable cause;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Throwable getCause() {
		return cause;
	}
	public void setCause(Throwable cause) {
		this.cause = cause;
	}
	
	public MyException(){}
	public MyException(String  message){
		this.message=message;
	}
	public MyException(Throwable cause){
		this.cause=cause;
	}
	public MyException(String  message, Throwable cause){
		this.message=message;
		this.cause=cause;
	}
	
	public void printStackTrace() {
		System.out.println("예외발생!");
		System.out.println("예외사유 : "+message);
		System.out.println("예외 클래스 : "+cause);
		System.out.println("Stack Trace 출력!!");
		super.printStackTrace(System.out);
	}
	
	public void printStacTrace(PrintStream out) {
		super.printStackTrace(out);
	}
	public void printStacTrace(PrintWriter out) {
		super.printStackTrace(out);
	}
	
	
	

}
