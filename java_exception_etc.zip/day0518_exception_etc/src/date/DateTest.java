package date;

import java.util.Date;

public class DateTest {

	public static void main(String[] args) {

		//날짜 정보 처리
		Date date=new Date();
		
		System.out.println("연도 : "+ (1900+date.getYear()));
		System.out.println("월 : "+ (1+date.getMonth()));//0월~
		System.out.println("일 : "+ (date.getDate()));
		System.out.println("시 : "+ date.getHours());
		System.out.println("분 : "+ date.getMinutes());
		System.out.println("초 : "+ date.getSeconds());

	}

}
