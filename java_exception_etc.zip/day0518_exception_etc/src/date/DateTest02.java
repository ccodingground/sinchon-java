package date;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class DateTest02 {

	public static void main(String[] args) {
		
		//
		LocalDateTime date=LocalDateTime.now();
		ZoneId zoneId=ZoneId.of("Europe/Paris");
		ZonedDateTime date1=ZonedDateTime.now(zoneId);
		ZonedDateTime date2=ZonedDateTime.now(ZoneId.of("Asia/Seoul"));
		
		System.out.println(date);
		System.out.println(date1);
		System.out.println(date2);
		
		System.out.println("연도 : "+ date.getYear());
		System.out.println("월 : "+ date.getMonth());
		System.out.println("월 : "+ date.getMonthValue());
		System.out.println("일 : "+ date.getDayOfMonth());
		
		System.out.println("시 : "+ date.getHour());
		System.out.println("분 : "+ date.getMinute());
		System.out.println("초 : "+ date.getSecond());
		
		LocalDate birth=LocalDate.of(2020,5,6);
		System.out.println("연도 : "+ birth.getYear());
		System.out.println("월 : "+ birth.getMonth());
		System.out.println("월 : "+ birth.getMonthValue());
		System.out.println("일 : "+ birth.getDayOfMonth());
		//LocalTime time;
		LocalDate eventDay=birth.plusDays(99);
		System.out.println(eventDay);
		
		
		

	}

}
