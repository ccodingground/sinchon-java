package inheritance;

public class Sub01 extends Super01{
	
	int x=100;
	int y=200;
	
	
	void disp() {
		System.out.println(x);
		System.out.println(y);
		a=10;
		b=20;
		System.out.println(a);
		System.out.println(b);
	}

}
