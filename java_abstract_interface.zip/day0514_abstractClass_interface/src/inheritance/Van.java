package inheritance;

public class Van extends Vehicle{
	
	Speed speed;// HAS-A 관계

}
