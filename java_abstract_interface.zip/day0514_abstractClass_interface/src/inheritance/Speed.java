package inheritance;

public class Speed {

}
