package inheritance;

public class Main02 {
	
	public static void main(String[] args) {
		
		Animal a=new Animal();
		Mammal m=new Mammal();
		Dog d=new Dog();
		
		System.out.println(m instanceof Animal);
		//포유동물은 동물입니다. m is a Animal
		System.out.println(d instanceof Mammal);
		//강아지는 포유동물입니다.d is a Mammal
		System.out.println(d instanceof Animal);
		//강아지는 동물입니다.   d is a Animal
		
		//IS-A 관계
		
	}

}
