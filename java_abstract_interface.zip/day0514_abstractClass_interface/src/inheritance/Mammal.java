package inheritance;

public class Mammal extends Animal{

}
