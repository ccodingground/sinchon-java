package inheritance;

public class Cat extends Mammal{

}
