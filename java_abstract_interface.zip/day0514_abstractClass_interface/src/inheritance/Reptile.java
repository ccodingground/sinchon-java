package inheritance;

public class Reptile extends Animal{

}
