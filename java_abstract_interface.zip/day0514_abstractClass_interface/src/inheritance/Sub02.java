package inheritance;

public class Sub02 extends Super02{
	
	public Sub02() {
		super();
	}

}
