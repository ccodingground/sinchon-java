package inheritance;

public class Main01 {

	public static void main(String[] args) {
		
		Sub01 sub=new Sub01();
		
		//sub.disp();
		
		Sub02 sub02=new Sub02();
		sub02.dispSuper();

	}

}
