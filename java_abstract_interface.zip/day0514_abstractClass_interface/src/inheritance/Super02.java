package inheritance;

public class Super02 {
	
	void dispSuper() {
		System.out.println("Super 클래스에서 만들어진 메서드입니다.");
	}

}
