package inheritance;

public class Animal {

}
