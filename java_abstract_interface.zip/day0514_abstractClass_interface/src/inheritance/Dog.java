package inheritance;

public class Dog extends Mammal{

}
