package inheritance;

public class Super01 {
	
	int a;
	int b;

}
