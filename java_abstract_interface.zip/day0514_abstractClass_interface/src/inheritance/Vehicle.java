package inheritance;

public class Vehicle {

}
