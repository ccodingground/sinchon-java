package ex4;

public interface SubInter extends Parent{
	
	public void disp3();

}
