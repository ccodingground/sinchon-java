package ex4;

public class MainC {
	public static void main(String[] args) {
		
		SubInter sub=new SubInter() {
			
			@Override
			public void disp() {
				System.out.println("Override disp");
				
			}
			
			@Override
			public void disp3() {
				System.out.println("Override disp3");
				
			}
		};
		
		sub.disp();
		sub.disp2();
		sub.disp3();
		
		
	}

}
