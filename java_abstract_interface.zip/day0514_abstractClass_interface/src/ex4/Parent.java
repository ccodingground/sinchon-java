package ex4;

public interface Parent {
	
	public void disp();
	public default void disp2() {
		System.out.println("default disp2");
	}

}
