package polymorphism;

public class AAA {
	
	int a;

}
