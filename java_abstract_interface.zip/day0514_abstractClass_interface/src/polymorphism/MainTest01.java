package polymorphism;

public class MainTest01 {

	public static void main(String[] args) {
		
		BBB b=new BBB();
		System.out.println(b.b);
		System.out.println(b.a);
		
		AAA ab=new BBB();
		System.out.println(ab.a);
		//System.out.println(ab.b);
		AAA ac=new CCC();
		System.out.println(ac.a);
		//System.out.println(ac.c);
		
		AAA[] ar=new AAA[2];
		// ar[0], ar[1]
		
		ar[0]=new BBB();
		ar[1]=new CCC();

	}

}
