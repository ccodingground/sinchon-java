package polymorphism;

public class BBB extends AAA{
	
	int b;

}
