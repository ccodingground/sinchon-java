package polymorphism;

public class CCC extends AAA{
	
	int c;

}
