package abstraction;

public  class Dog extends Animal{

	@Override
	public void crying() {
		System.out.println("멍멍");
		
	}
	//일반클래스가 추상클래스를 상속하면 추상클래스의 추상메서드는
	//반드시 Override 해야한다.
	
}
