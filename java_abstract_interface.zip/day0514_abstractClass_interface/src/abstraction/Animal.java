package abstraction;


//추상클래스(미완성 클래스)
public abstract class Animal {
	int a=10;
	void disp() {
		System.out.println(a);
	}
	//추상메서드
	//미완성메서드
	public abstract void crying();
	public Animal() {
		// TODO Auto-generated constructor stub
	}

}
