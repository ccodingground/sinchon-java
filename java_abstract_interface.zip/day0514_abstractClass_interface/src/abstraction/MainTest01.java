package abstraction;

public class MainTest01 {

	public static void main(String[] args) {
		
		
		//Animal a=new Animal();
		//abstract class 단독으로는 객체생성불가
		//단.예외는 있다..
		//상속해서 쓰세요...
		Animal a=new Dog();
		a.crying();
		a.disp();

	}

}
