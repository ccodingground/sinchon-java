package interfaces;

public class DDDClass /*extends AAA*/{
	//클래스 extends 인터페이스 사용불가
}
