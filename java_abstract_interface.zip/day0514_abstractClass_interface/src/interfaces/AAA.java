package interfaces;

public interface AAA {
	//데이터 타입으로 사용
	//interface 구성요소: 멤버...
	//1. 멤버필드
	static final int A=10;
	double PI=3.14;
	//모든 멤버필드는 static final멤버(상수)이다.
	//관례로 상수는 대문자로 표현하자...
	//static final 생략되어있다.
	//2. 메서드
	//기본적으로 일반메서드는 허용않한다.
	public void disp();
	//바디({})없는 메서드 , 미완성드 메서드 
	//추상 메서드입니다.
	//abstract 키워드는 생략해도 됩니다.
	public abstract void disp1();
	
	//public AAA() {}
	// 생성자가 존재하지 않습니다.
	// 객체 생성이 불가합니다...
	//추상메서드의 집합...
	
	//java8버전부터 추가된 사항
	//일반메서드허용( default 키워드를 사용해서..)
	public default void disp2() {
	}
	//static 메서드 허용
	public static void disp3() {
	}
	

}
