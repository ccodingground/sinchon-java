package interfaces;

public class MainClass {

	public static void main(String[] args) {
		
		
		System.out.println( AAA.A );
		System.out.println( AAA.PI);
		//a,PI static 멤버이다..
		//AAA a=new AAA();
		//class 구현처리해 객체생성...
		
		AAA a=new EEE();
		DDDClass d=new EEE();
		CCC c=new EEE();
		
		AAA aa=new AAA() {

			@Override
			public void disp() {
				System.out.println("출력!");
				
			}

			@Override
			public void disp1() {
				System.out.println("disp1");
				
			}
			
		};
		
		aa.disp();
		aa.disp1();

	}

}
