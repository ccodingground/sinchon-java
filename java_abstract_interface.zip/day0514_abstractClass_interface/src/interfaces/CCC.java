package interfaces;

public interface CCC /*extends DDDClass*/{
	//인테페이스는 extends 클래스  않됩니다.
}
