package interfaces;

public class EEE extends DDDClass implements AAA, CCC{
	//implements 로 클래스에 구현해서 사용합니다.
	//미완성interface 를 완성형표현인 class 합친다.
	//완성형으로 만들어줘야한다...미완성메서드를 구현({}바디를 만들어라)
	//Override하세요...
	//다중구현가능 , 추가로 상속표현도 가능하다..
	
	
	@Override
	public void disp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disp1() {
		// TODO Auto-generated method stub
		
	}
	
}
