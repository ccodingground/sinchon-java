package interfaces;

public interface BBB extends AAA,CCC{
	//인터페이스 대 인터페이스는 다중 상속가능
}
