package ex3;

public class DefaultTest {

	public static void main(String[] args) {
		
		MyInterface m=new MyClassA();
		m.method1();
		m.method2();
		
		m=new MyClassB();
		m.method1();
		m.method2();

	}

}
