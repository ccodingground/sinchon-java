package ex3;

public class MyClassB implements MyInterface{

	@Override
	public void method1() {
		
		System.out.println("MyClassB_메서드1");
		
	}
	//default메서드는 선택적으로 Override가능
	@Override
	public void method2() {
		System.out.println("MyClassB_메서드2");
	}
	
	

	

}
