package ex3;

public interface MyInterface {
	
	public void method1();
	
	//java8이상에서 사용가능
	public default void method2() {
		System.out.println("Myinterface_메서드2");
	}

}
