package ex;

public class Car {
	
	Tire[] tire;
	
	void run() {
		/*
		for(int i=0; i<4; i++) {
			tire[i].roll();
		}
		*/
		for(Tire t:tire) {
			t.roll();
		}
	}
	public Car(){
		tire=new Tire[4];
		
		for(int i=0; i<4; i++) {
			tire[i]=new HankookTire();
		}
	}

}
