package ex;

public class CarEx {

	public static void main(String[] args) {
		
		Car car=new Car();
		car.run();
		
		car.tire[0]=new KumhoTire();
		car.tire[1]=new KumhoTire();
		
		car.run();
		

	}

}
