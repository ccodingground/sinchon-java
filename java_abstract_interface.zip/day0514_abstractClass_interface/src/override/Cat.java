package override;

public class Cat extends Animal{

	@Override
	public void crying() {
		System.out.println("고양이는 야옹야옹~~~");
	}
	
	
	

}
