package override;

public class Animal {
	
	public void move() {
		System.out.println("동물은 움직일수 있다.");
	}
	
	public void crying() {
		System.out.println("동물은 소리를 냅니다.");
	}

}
