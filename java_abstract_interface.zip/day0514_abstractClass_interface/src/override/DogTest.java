package override;

import java.util.Scanner;

public class DogTest {

	public static void main(String[] args) {
		
		Animal a=new Animal();
		a.move();
		//Animal b=new Dog();
		//b.move();
		//b.crying();
		
		//Animal c=new Cat();
		//c.crying();
		Animal an=null;
		System.out.print("선택(1.강아지 2.고양이)>");
		
		Scanner in=new Scanner(System.in);
		int sw=in.nextInt();
		
		switch(sw) {
		case 1:
			an=new Dog();
			break;
		case 2:
			an=new Cat();
		}
		
		if(an!=null) {
			an.crying();
		}

	}

}
