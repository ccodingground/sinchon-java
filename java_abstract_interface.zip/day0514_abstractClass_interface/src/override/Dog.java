package override;

public class Dog extends Animal{
	
	@Override
	public void move() {
		System.out.println("강아지는 걷거나 달릴수 있다.");
	}

	@Override
	public void crying() {
		
	}
	

}
