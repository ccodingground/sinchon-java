package ex2;

public class Driver {
	
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}

}
