package ex2;

public class Bus implements Vehicle{

	@Override
	public void run() {
		System.out.println("버스를 타고 갑니다.");
		
	}

}
