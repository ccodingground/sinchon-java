package ex2;

public interface Vehicle {
	
	public void run();
	//추상메서드

}
