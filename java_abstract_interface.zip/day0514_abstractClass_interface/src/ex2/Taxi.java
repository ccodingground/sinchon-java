package ex2;

public class Taxi implements Vehicle{

	@Override
	public void run() {
		System.out.println("택시를 타고 갑니다.");
		
	}

}
