package ex2;

import java.util.Scanner;

public class DriveEx {

	public static void main(String[] args) {
		
		
		Driver d=new Driver();
		
		System.out.print("(1.택시 2.버스)선택 > ");
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		
		Vehicle vehicle=null;
		switch(n) {
		case 1:
			vehicle=new Taxi();
			break;
		case 2:
			vehicle=new Bus();
		}
		
		if(vehicle!=null)
			vehicle.run();
		

	}

}
