package constructors;

public class ConstructorMain01 {

	public static void main(String[] args) {
		
		//객체생성
		ConstructorTest01 con=new ConstructorTest01();
		System.out.println( con.a );
		//객체생성
		ConstructorTest01 obj=new ConstructorTest01(10);
		
		System.out.println( obj.a);
		System.out.println( con.a );

	}

}
