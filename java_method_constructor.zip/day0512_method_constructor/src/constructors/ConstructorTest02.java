package constructors;

public class ConstructorTest02 {
	
	String id;
	String pw;
	String name;
	int age;
	
	void disp() {
		System.out.println("id : "+id);
		System.out.println("pw : "+pw);
		System.out.println("name : "+name);
		System.out.println("age : "+age);
		System.out.println();
	}
	public ConstructorTest02() {
		// TODO Auto-generated constructor stub
	}
	ConstructorTest02(String id){
		this.id=id;
	}
	ConstructorTest02(String id, String pw){
		this(id);//this생성자
		this.pw=pw;
	}
	ConstructorTest02(String id, String pw, String name){
		this(id, pw);//위치는 첫줄에서 사용
		this.name=name;
	}
	ConstructorTest02(String id, String pw, String name, int age){
		this(id, pw, name);
		this.age=age;
	}

}
