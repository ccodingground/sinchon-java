package constructors;

public class ConstructorMain02 {

	public static void main(String[] args) {
		
		ConstructorTest02 obj1=new ConstructorTest02("id_486");
		obj1.disp();
		
		ConstructorTest02 obj2=new ConstructorTest02("idaa","1234");
		obj2.disp();
		
		ConstructorTest02 obj3=new ConstructorTest02("ㅠㅠㅠ","5555","조재청");
		obj3.disp();
		
		ConstructorTest02 obj4=new ConstructorTest02("cccc","6666","조인성", 20);
		obj4.disp();
		

	}

}
