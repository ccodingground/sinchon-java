package constructors;

public class ConstructorTest01 {
	int a;
	//1. 멤버 필드(변수)
	//2. 멤버 메서드
	//3. 멤버 생성자
	//4. 멤버 클래스
	
	ConstructorTest01(){}
	ConstructorTest01(int a){
		this.a=a;
	}
	//default 생성자는
	//다른생성자를 명시하면사용불가

}
