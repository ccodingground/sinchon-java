package ex;

public class ExTest01 {
	
	private int kor;//class내부에서만 접근허용
	private int eng;
	
	public void setKor(int kor) {
		this.kor=kor;
	}
	public void setEng(int eng) {
		this.eng=eng;
	}
	public int getKor() {
		return kor;
	}
	public int getEng() {
		return eng;
	}
	@Override
	public String toString() {
		return "ExTest01 [kor=" + kor + ", eng=" + eng + "]";
	}
	
	
	
	
}
