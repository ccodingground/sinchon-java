package ex;

import java.util.Scanner;

public class CalcuMain {

	public static void main(String[] args) {
		
		Calcu cal=new Calcu();
		
		cal.powerOn();
		
		Scanner in=new Scanner(System.in);
		
		
		while(true) {
			System.out.println("메뉴를 선택하세요!(1.+ 2./ 3.종료)");
			System.out.print("선택 > ");
			int sw=in.nextInt();
			
			
			switch(sw) {
			case 1:
				System.out.print("첫번째 숫자 : ");
				int n1=in.nextInt();
				System.out.print("두번째 숫자 : ");
				int n2=in.nextInt();
				System.out.println("더 하기 연산 !");
				int result=cal.plus(n1, n2);
				System.out.println("덧셈결과 : "+result);
				break;
			case 2:
				System.out.print("첫번째 숫자 : ");
				int n3=in.nextInt();
				System.out.print("두번째 숫자 : ");
				int n4=in.nextInt();
				System.out.println("나누기 연산!");
				double r=cal.divide(n3, n4);
				System.out.println("나눗셈 결과 : "+ r);
				break;
			case 3:
				cal.powerOff();
				//return; //메서드 종료
				System.exit(0);
				
			}
		}
		
		
		
		
		
	}

}
