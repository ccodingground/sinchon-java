package ex;

import java.util.Scanner;

public class ExMain01 {

	public static void main(String[] args) {
		
		ExTest01[] ex=new ExTest01[2]; 
		//ex[0], ex[1], ex[2]
		
		
		for(int i=0; i<ex.length ; i++) {
			//객체 생성
			ex[i]=new ExTest01();
			//값을 셋팅
			System.out.println(i+1+"번 시험점수를 입력해 주세요!");
			Scanner in=new Scanner(System.in);
			System.out.print("영어: ");
			int eng=in.nextInt();
			ex[i].setEng(eng);
			System.out.print("국어: ");
			int kor=in.nextInt();
			ex[i].setKor(kor);
		
		}
		
		
		//출력
		
		for(ExTest01 obj : ex) {
			//System.out.println(obj.toString());
			System.out.println(obj);
		}
		
		
		
		
	}

}


