package ex;

public class Calcu {
	
	//메서드
	void powerOn() {
		System.out.println("전원을 켭니다.");
	}
	
	void powerOff() {
		System.out.println("전원을 끕니다.");
	}
	
	int plus(int a, int b){
		int result=a+b;
		return result;
	}
	
	double divide(int a, int b){
		double result=(double)a/b;
		return result;
	}

}
