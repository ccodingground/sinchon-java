package methods;

public class MethodTest06 {
	
	//메서드 오버로딩(overroading)
	int plus(int a, int b) {
		return a+b;
	}
	double plus(double a, int b) {
		return a+b;
	}
	int plus(int n) {
		return n+10;
	}
	double plus(double a, double b) {
		return a+b;
	}
	

}
