package methods;

public class MethodTest05 {
	int a;
	//리턴(O) 매개변수(O)
	int add(int n, int m) {
		return n+m;
	}
	
	double div(int n, int m) {
		return (double)n/m;
	}
	
	
	MethodTest05(){
	}

}
