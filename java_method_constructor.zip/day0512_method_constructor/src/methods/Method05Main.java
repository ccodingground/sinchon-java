package methods;

public class Method05Main {

	public static void main(String[] args) {
		// 객체생성
		
		MethodTest05 obj=new MethodTest05();
		
		//int r=obj.add(10, 20);
		System.out.println( obj.add(10, 20) );
		
		System.out.println( obj.div(7, 3) );

	}

}
