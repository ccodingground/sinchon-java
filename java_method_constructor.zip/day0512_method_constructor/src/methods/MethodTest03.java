package methods;

class AAA{
	//리턴타입(x) 매개변수(O)
	void disp(String name){
		System.out.println("안녕하세요~ "+name +" 님!");
	}
	//AAA(){} default는 생략되어있다.
}

///////////////////////////////////////////
public class MethodTest03 {

	public static void main(String[] args) {
		
		AAA obj=new AAA();
		obj.disp("더조은");
	}

}
/////////////////////////////////////////////
