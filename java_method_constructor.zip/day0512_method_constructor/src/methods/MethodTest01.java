package methods;

public class MethodTest01 {
	//
	public static int methodName(int a, int b) {
		
		return a+b;	
	}
	//메서드 생성규칙 (리턴타입 존재유무, 매개변수 존재유무)
	//1. 리턴타입(O) 메서드네임(매개변수(O)){}
	//2. 리턴타입(O) 메서드네임(매개변수(x)){}
	//3. 리턴타입(x) 메서드네임(매개변수(O)){}
	//4. 리턴타입(x) 메서드네임(매개변수(x)){}
	

	//main 메서드
	public static void main(String[] args) {
		//int result=methodName(10,20);
	}

}//class

