package methods;

public class MethodTest04 {
	
	int num;//클래스변수
	
	//메서드 정의
	//리턴타입존재(O) 매개변수(x)
	int getNum() {
		return num;
	}
	//return_value 와 return Type 이 일치해야한다.
	
	void disp(int num) {
		System.out.println("num : " + num);
	}
	
	void setNum(int num) {
		this.num=num;
	}

}
