package methods;

public class CarMain {

	public static void main(String[] args) {
		
		//객체생성
		
		Car[] cars=new Car[2];
		//1차원배열
		// cars[0], cars[1]
		cars[0]=new Car();
		cars[0].setModel("제네시스");
		cars[0].run();
		
		cars[1]=new Car();
		cars[1].setModel("소나타");
		cars[1].run();
		
		
	}

}
