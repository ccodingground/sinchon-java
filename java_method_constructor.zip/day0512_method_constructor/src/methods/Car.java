package methods;

public class Car {
	//멤머 필드
	
	String model;
	int speed;
	
	//멤버 메서드
	void setModel(String model) {
		this.model = model;
	}
	void setSpeed(int speed) {
		this.speed = speed;
	}
	
	void run() {
		for(int i=10; i<=50; i+=10) {
			setSpeed(i);
			
			System.out.print(model +"가(이) 달립니다.\t");
			System.out.println("(시속 : "+speed +"km/h)");
			
		}
	}
	

}
