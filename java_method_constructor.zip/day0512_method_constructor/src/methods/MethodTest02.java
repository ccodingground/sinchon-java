package methods;

import java.util.Scanner;

public class MethodTest02 {
	//멤버필드
	int a;
	//멤버 메서드 생성 : 메서드 정의 (Method definition)
	//리텁타입(void) 매개변수(x)
	void disp() {
		System.out.println("안녕하세요");
		System.out.println("메서드가 호출된면");
		System.out.println("바디의 내용이 처리된다.");
	}
	void disp2() {
		disp();//메서드 호출
		disp();
	}
	
	public static void main(String[] args) {
		//객체 생성
		MethodTest02 obj=new MethodTest02();
		//객체 멤버 접근 .
		//obj.disp();//호출 method call
		obj.disp2();
		
	}

}
