package methods;

public class Method04Main {

	public static void main(String[] args) {
		
		//객체를 생성...
		MethodTest04 obj=new MethodTest04();
		obj.setNum(1000);
		
		
		int result=obj.getNum();
		//System.out.println(result);
		
		obj.disp(result);

	}

}
